
document.getElementById('downloadBtn').addEventListener('click', function () {
    const videoUrl = document.getElementById('videoUrl').value;
    const message = document.getElementById('message');

    // Verificar que la URL no esté vacía
    if (!videoUrl) {
        message.textContent = 'Por favor, ingresa una URL válida.';
        return;
    }

    // Comprobar si la URL tiene un formato válido
    try {
        new URL(videoUrl);  // Esto valida la URL
    } catch (e) {
        message.textContent = 'La URL no es válida.';
        return;
    }

    // Mensaje de que se está iniciando la descarga
    message.textContent = 'Iniciando descarga...';

    // Crear un enlace temporal para descargar el video
    const a = document.createElement('a');
    a.href = videoUrl;
    a.download = '';  // Si se desea un nombre personalizado para el archivo, se puede agregar aquí
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);

    // Mensaje de éxito
    message.textContent = '¡Descarga iniciada!';
});
